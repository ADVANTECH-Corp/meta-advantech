#include "SimulatorLib.h"

#include <stdio.h>
#include <string.h>
#include <map>
#include <sys/stat.h>

static json_t *Simulator_Json = NULL;
std::map<int, SimulatorDataItem*> _items;

/*
 * Check if a file exist using stat() function
 * return 0 if the file exist
 */
static int cfileexists(const char* filename){
    struct stat buffer;
    return stat(filename,&buffer);
}

uint8_t SUSI_IOT_API SusiIoTGetModuleID()
{
	return 0xFE;
}

SusiIoTStatus_t SUSI_IOT_API SusiIoTInitialize(void)
{
	json_error_t error;
	std::string jsonfilepath = "";
	std::string txtfilepath = "";

#ifdef _WIN64
	jsonfilepath.append(SIM_FILE_X64_PATH);
#else
	jsonfilepath.append(SIM_FILE_X32_PATH);
#endif
	txtfilepath = jsonfilepath;

	jsonfilepath.append(SIM_JSON_FILE_NAME);
	txtfilepath.append(SIM_TXT_FILE_NAME);

	// Check if there is a SIM file in the same folder of the calling application, if not, check the windows/dll/x32 or x64 path.
	if(cfileexists(SIM_JSON_FILE_NAME) == 0)
	{
		Simulator_Json = json_load_file(SIM_JSON_FILE_NAME, 0, &error);
	}
	else if(cfileexists(SIM_TXT_FILE_NAME) == 0)
	{
		Simulator_Json = json_load_file(SIM_TXT_FILE_NAME, 0, &error);
	}	
	else if (cfileexists(jsonfilepath.c_str()) == 0)
	{
		Simulator_Json = json_load_file(jsonfilepath.c_str(), 0, &error);
	}	
	else if (cfileexists(txtfilepath.c_str()) == 0)
	{
		Simulator_Json = json_load_file(txtfilepath.c_str(), 0, &error);
	}
	else
	{
		return SUSIIOT_STATUS_INVALID_PARAMETER;
	}

	if (json_object_size(Simulator_Json) <= 0)
	{
		fprintf( stderr, "Example.json parse error: on line %d: %s\n", error.line, error.text );
		return SUSIIOT_STATUS_INVALID_PARAMETER;
	}
	return SUSIIOT_STATUS_SUCCESS;
}

SusiIoTStatus_t SUSI_IOT_API SusiIoTUninitialize(void)
{
	return SUSIIOT_STATUS_SUCCESS;
}

SusiIoTStatus_t SUSI_IOT_API SusiIoTGetMDCapability(json_t *capability)
{
	json_dumps(Simulator_Json,0);

	json_object_clear(capability);
	json_t *temp = json_deep_copy(Simulator_Json);

	if (json_object_update(capability, temp))
	{
		printf("SUSIIoT get Cap: unable to update an empty object with an empty object\n");
		return SUSIIOT_STATUS_ERROR;
	}

	json_object_clear(temp);
	json_decref(temp);

	return SUSIIOT_STATUS_SUCCESS;
}

bool SaveJsonObjectOtherProperties(json_t * jobject, int Id)
{
	const char *key;
	json_t *value = NULL;

	json_t *tempValue = NULL;
	json_t *tempMin = NULL;
	json_t *tempMax = NULL;
	std::string tempName;
	std::string tempAccessMode;
	int tempSimMode = 0;

	json_object_foreach(jobject, key, value)
	{
		if (strcmp(key, "bv") == 0 || strcmp(key, "sv") == 0 || strcmp(key, "v") == 0)
		{
			tempValue = value;
		}
		else if (strcmp(key, "min") == 0)
		{
			tempMin = value;
		}
		else if (strcmp(key, "max") == 0)
		{
			tempMax = value;
		}
		else if (strcmp(key, "n") == 0)
		{
			tempName = json_string_value(value);
		}
		else if (strcmp(key, "acm") == 0)
		{
			tempAccessMode = json_string_value(value);
		}
		else if (strcmp(key, "simMode") == 0)
		{
			tempSimMode = (int)json_integer_value(value);
			if (tempSimMode < SimulatorDataItem::Deactivate || tempSimMode > (SimulatorDataItem::ModeCount - 1))
			{
				tempSimMode = SimulatorDataItem::Deactivate;
			}
		}
	}	

	_items[Id] = new SimulatorDataItem(Id, tempName, tempAccessMode, tempMax, tempMin, tempValue, tempSimMode);
	return true;
}

bool SearchIDInJsonObjectRecursion(json_t * jobject, int Id)
{
	const char *key;
	json_t *value = NULL;
	json_t *subValue = NULL;
	size_t index;

	bool ret = false;

	// if the data item is in this tier.
	json_object_foreach(jobject, key, value)
	{
// 		if ((json_object_size(value) != 0) && ((ret = SearchJsonObjectRecursion(value, Id)) != NULL))
// 			return false;

		if (strcmp(key, "id") == 0)
		{
			if ( json_integer_value(value) == Id)
			{
				ret = SaveJsonObjectOtherProperties(jobject, Id);
			}
		}
	}

	// if the data item is not in this tier, go into next tier.
	if (ret == false)
	{
		json_object_foreach(jobject, key, value)
		{
			if (strcmp(key, "e") == 0)
			{
				// if there is an array in this tier, go into the "e" property
				json_array_foreach(value, index, subValue)
				{
					if (SearchIDInJsonObjectRecursion(subValue, Id) == true)
					{
						ret = true;
					}
				}
			}
			else if (SearchIDInJsonObjectRecursion(value, Id) == true)
			{
				ret = true;
			}
		}
	}

	return ret;
}

bool createSimulatorDataItem(int Id)
{
	const char *key;
	json_t *value = NULL;

	//json_dumps(Simulator_Json,0);
	json_object_foreach(Simulator_Json, key, value)
	{
		// go into each first tier classes
		if (SearchIDInJsonObjectRecursion(value, Id) == true)
		{
			return true;
		}
	}

	return false;
}

SusiIoTStatus_t SUSI_IOT_API SusiIoTGetMDValue(SusiIoTId_t id, json_t *jValue)
{
	bool ret = true;

	if (_items.find(id) == _items.end())
	{
		ret = createSimulatorDataItem(id);
		printf("createSimulatorDataItem %d \n", id);
	}
	
	if (ret == true)
	{
		return _items[id]->getValue(jValue);
	}
	else
	{
		printf("SusiIoTGetMDValue %d SUSIIOT_STATUS_NOT_FOUND\n", id);
		return SUSIIOT_STATUS_NOT_FOUND;
	}
}

SusiIoTStatus_t SUSI_IOT_API SusiIoTSetMDValue(SusiIoTId_t id, json_t *jValue)
{
	bool ret = true;

	if (_items.find(id) == _items.end())
	{
		ret = createSimulatorDataItem(id);
	}

	if (ret == true)
	{
		return _items[id]->setValue(jValue);
	}
	else
	{
		return SUSIIOT_STATUS_NOT_FOUND;
	}
}

SusiIoTStatus_t SUSI_IOT_API SusiIoTSetMDEventHandler(SUSI_IOT_EVENT_CALLBACK eventCallbackFun)
{
	return 0;
}

SusiIoTStatus_t SUSI_IOT_API SusiIoTGetMDStringA(SusiIoTId_t id, char *pBuffer, uint32_t *pBufLen)
{
	return 0;
}
