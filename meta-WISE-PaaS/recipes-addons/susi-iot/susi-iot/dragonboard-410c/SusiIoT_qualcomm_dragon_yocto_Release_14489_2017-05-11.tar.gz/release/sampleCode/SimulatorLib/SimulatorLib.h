#ifndef _SIMULATOR_LIB_H_
#define _SIMULATOR_LIB_H_

#include "SimulatorDataItem.h"

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once

#ifndef SUSI_IOT_API
#define SUSI_IOT_API __stdcall
#endif
#else
#define SUSI_IOT_API
#endif

#ifndef _LINUX
#if defined(_WIN64)
#pragma comment(lib,"../lib/x64/IoTJsonLibrary.lib")
#pragma comment(lib,"../lib/x64/jansson.lib")
#else
#pragma comment(lib,"../lib/Win32/IoTJsonLibrary.lib")
#pragma comment(lib,"../lib/Win32/jansson.lib")
#endif
#endif

#define SIM_JSON_FILE_NAME "Example.json"
#define SIM_TXT_FILE_NAME "Example.txt"
#define SIM_FILE_X32_PATH "C:\\Windows\\SUSI\\DLL\\x32\\" 
#define SIM_FILE_X64_PATH "C:\\Windows\\SUSI\\DLL\\x64\\" 

typedef void (SUSI_IOT_API *SUSI_IOT_EVENT_CALLBACK)(SusiIoTId_t id, char *jsonstr); 

SusiIoTStatus_t SUSI_IOT_API SusiIoTInitialize(void);
SusiIoTStatus_t SUSI_IOT_API SusiIoTUninitialize(void);

SusiIoTStatus_t SUSI_IOT_API SusiIoTGetMDCapability(json_t *capability);
SusiIoTStatus_t SUSI_IOT_API SusiIoTGetMDValue(SusiIoTId_t id, json_t *pValue);
SusiIoTStatus_t SUSI_IOT_API SusiIoTSetMDValue(SusiIoTId_t id, json_t *pValue);

SusiIoTStatus_t SUSI_IOT_API SusiIoTSetMDEventHandler(SUSI_IOT_EVENT_CALLBACK eventCallbackFun);

uint8_t SUSI_IOT_API SusiIoTGetModuleID();

#endif /* _SIMULATOR_LIB_H_ */

