#ifndef __SIMULATOR_DATA_ITEM_H__
#define __SIMULATOR_DATA_ITEM_H__

#include <OsDeclarations.h>
#include "SusiIoT.h"
#include "jansson.h"
#include <string>

class SimulatorDataItem
{
public:
	SimulatorDataItem(int ID, std::string name, std::string am, json_t* max,  json_t* min,  json_t* value, int simMode);
	~SimulatorDataItem();

	SusiIoTStatus_t getValue(json_t *jValue);
	SusiIoTStatus_t setValue(json_t *jValue);
	void freeJsonObject(json_t* jobj);

	enum SimulatingMode
	{
		Deactivate,
		Random,
		ModeCount
	};

private:
	typedef union JsonValue {
		int integerValue;
		double realValue;
		char stringValue[64];
	} JsonValue;

	int _ID;
	int _simMode;
	std::string _name;
	std::string _am;
	json_t* _min;
	json_t* _max;
	json_t* _value;
};

#endif //__SIMULATOR_DATA_ITEM_H__