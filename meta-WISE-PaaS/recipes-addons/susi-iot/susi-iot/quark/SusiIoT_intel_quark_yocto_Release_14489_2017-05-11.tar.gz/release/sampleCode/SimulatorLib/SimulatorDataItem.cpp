#include "SimulatorDataItem.h"
#include "time.h"

SimulatorDataItem::SimulatorDataItem(int ID, std::string name, std::string am, json_t* max,  json_t* min,  json_t* value, int simMode)
{
	srand((unsigned int)time(NULL));

	_ID = ID;
	_name = name;
	_am = am;
	_simMode = simMode;

	if (min != NULL)
	{
		_min = json_copy(min);
	}

	if (max != NULL)
	{
		_max = json_copy(max);
	}

	_value = json_copy(value);
}

void SimulatorDataItem::freeJsonObject(json_t* jobj)
{
	if (jobj != NULL)
	{
		json_decref(jobj);
		json_object_clear(jobj);
	}
}

SimulatorDataItem::~SimulatorDataItem()
{
	freeJsonObject(_min);
	freeJsonObject(_max);
	freeJsonObject(_value);
}

SusiIoTStatus_t SimulatorDataItem::getValue(json_t *jValue)
{
	JsonValue tempJsonValue;
	int tempMax = 0;
	int tempMin = 0;

	switch (json_typeof(_value))
	{
	case JSON_INTEGER:
		if (_simMode == Random)
		{
			if (_max != NULL && _min != NULL)
			{
				tempMax = (int)json_integer_value(_max);
				tempMin = (int)json_integer_value(_min);
			}
			tempJsonValue.integerValue = (( (rand()*rand()) % ((tempMax - tempMin + 1) ) + tempMin));
			
			json_integer_set(_value, (int)(tempJsonValue.integerValue));
		}

		json_integer_set(jValue, json_integer_value(_value));
		break;

	case JSON_REAL:
		if (_simMode == Random)
		{
			if (_max != NULL && _min != NULL)
			{
				tempMax = (int)(json_real_value(_max)*100);
				tempMin = (int)(json_real_value(_min)*100);
			}
			tempJsonValue.realValue = (( (rand()*rand()) % ((tempMax - tempMin + 1) ) + tempMin)) / 100.0;

			json_real_set(_value, tempJsonValue.realValue);
		}

		json_real_set(jValue, json_real_value(_value));
		break;

	case JSON_STRING:
		json_string_set(jValue, json_string_value(_value));
		break;

	case JSON_TRUE:
	case JSON_FALSE:
		if (_simMode == Random)
		{
			json_integer_set(_value, rand() % 2);	
		}

		json_integer_set(jValue, json_integer_value(_value));
		break;

	default:
		printf("Simulator Get Value: not a json integer, real or string\n");
		return SUSIIOT_STATUS_JSON_TYPE_ERROR;
	}

	return SUSIIOT_STATUS_SUCCESS;
}

SusiIoTStatus_t SimulatorDataItem::setValue(json_t *jValue)
{
	// If the simulating mode is not deactivate, there is no meaning to set a value, because the value is generated randomly every getValue().
	if (_simMode == Deactivate)
	{
		switch (json_typeof(jValue))
		{
		case JSON_INTEGER:
			json_integer_set(_value, json_integer_value(jValue));
			break;

		case JSON_REAL:
			json_real_set(_value, json_real_value(jValue));
			break;

		case JSON_STRING:
			json_string_set(_value, json_string_value(jValue));
			break;

		case JSON_TRUE:
		case JSON_FALSE:
			json_integer_set(_value, json_integer_value(jValue));				
			break;

		default:
			printf("Simulator Set Value: not a json integer, real or string\n");
			return SUSIIOT_STATUS_JSON_TYPE_ERROR;
		}
	}

	return SUSIIOT_STATUS_SUCCESS;
}